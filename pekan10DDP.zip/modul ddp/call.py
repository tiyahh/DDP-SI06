import ddp_pekan10

print('## Perhitungan luas bangun datar ##')

ddp_pekan10.luas_persegi(10)

ddp_pekan10.persegi_panjang(2,4)

ddp_pekan10.luas_segitiga(3,4)

ddp_pekan10.luas_jajargenjang(5,6)

ddp_pekan10.luas_lingkaran(14)

ddp_pekan10.layang2(5,10)


import ddp_pekan10

print('## Perhitungan luas bangun ruang ##')

ddp_pekan10.luas_balok(10,5,6)

ddp_pekan10.luas_bola(49)

ddp_pekan10.luas_kubus(10)

ddp_pekan10.luas_tabung(14,10)

ddp_pekan10.luas_kerucut(22,21)


import ddp_pekan10

print('## Perhitungan ##')

ddp_pekan10.tambah(3,5)

ddp_pekan10.bagi(10,2)

ddp_pekan10.kali(10,8)

ddp_pekan10.kurang(7,9)
